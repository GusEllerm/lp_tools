from lp_ap_tools import lp_ap_tools

def test_lp_tools():
    assert lp_ap_tools.LP_artefact is not None